import flet as ft
import random
import time

number_sequence = []
user_sequence = []
sequence_length = 3  

def generate_sequence(length):
    return [random.randint(0, 9) for _ in range(length)]


def display_sequence(page):
    for number in number_sequence:
        page.add(ft.Text(str(number)))
        page.update()
        time.sleep(1)
        page.clean()


def start_game(page):
    global number_sequence, user_sequence, sequence_length
    number_sequence = generate_sequence(sequence_length)
    user_sequence =  [None] * sequence_length
    
    page.clean()
    page.add(ft.Text("Remember this sequence:",
             style=ft.TextStyle(size=20,weight="bold")))
    page.update()
    time.sleep(2)
    page.clean()

    display_sequence(page)
    
    page.add(ft.Text("Enter the sequence:",
             style=ft.TextStyle(size=20,weight="bold")))
    page.update()
    for i in range(sequence_length):
        page.add(ft.TextField(label=f"Number {i+1}", on_change=lambda e, i=i: user_input(e, i)))
    page.add(ft.ElevatedButton("Submit", on_click=check_sequence))


def user_input(event, index):
    user_sequence[index] = int(event.control.value)


def check_sequence(event):
    global sequence_length
    print(user_sequence,number_sequence)
    if user_sequence == number_sequence:
        sequence_length += 1
        event.page.clean()
        event.page.add(ft.Text("Correct! Get ready for the next sequence.",
                      style=ft.TextStyle(size=20)))
    else:
        event.page.clean()
        event.page.add(ft.Text("Incorrect! Try again.",
                      style=ft.TextStyle(size=20)))
        sequence_length = 3
    
    event.page.add(ft.ElevatedButton("Start Again", on_click=lambda e: start_game(e.page)))


def main(page):
    page.title = "Number Memory Game"
    page.add(ft.Text("Welcome to the Number Memory Game!",
             style=ft.TextStyle(size=30,weight="bold")))
    page.add(ft.ElevatedButton("Start Game", on_click=lambda e: start_game(page)))

ft.app(target=main)